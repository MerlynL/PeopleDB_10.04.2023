package com.Mlink.peopledb.model;

public enum CRUDOperation {
    SAVE,
    UPDATE,
    FIND_BY_ID,
    FIND_ALL,
    DELETE_ONE,
    DELETE_MANY,
    COUNT
}
